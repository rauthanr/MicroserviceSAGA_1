package com.ravio.food.ordering.system.payment.service.domain.valueobject;

public enum TransactionType {
    DEBIT, CREDIT
}
