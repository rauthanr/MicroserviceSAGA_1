package com.ravio.food.ordering.system.payment.service.dataaccess.payment.exception;

public class PaymentDataaccessException extends RuntimeException {

    public PaymentDataaccessException(String message) {
        super(message);
    }
}
