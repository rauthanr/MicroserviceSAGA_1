package com.ravio.food.ordering.system.payment.service.dataaccess.creditentry.exception;

public class CreditEntryDataaccessException extends RuntimeException {

    public CreditEntryDataaccessException(String message) {
        super(message);
    }
}
