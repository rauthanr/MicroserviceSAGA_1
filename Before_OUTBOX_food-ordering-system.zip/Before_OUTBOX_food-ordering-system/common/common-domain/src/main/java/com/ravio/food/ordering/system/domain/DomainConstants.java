package com.ravio.food.ordering.system.domain;

public class DomainConstants {

    public final static String UTC = "UTC";
}
