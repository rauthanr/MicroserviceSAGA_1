package com.ravio.food.ordering.system.domain.valueobject;

public enum OrderApprovalStatus {
    APPROVED, REJECTED
}
