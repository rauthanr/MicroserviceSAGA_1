package com.ravio.food.ordering.system.domain.entity;

public abstract class AggregateRoot<ID> extends BaseEntity<ID>{
}
